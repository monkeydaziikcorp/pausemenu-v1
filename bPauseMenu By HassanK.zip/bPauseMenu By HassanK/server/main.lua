ESX = nil 

	TriggerEvent(_bConfig.InitESX, function(obj) ESX = obj end)

ESX.RegisterServerCallback("bPauseMenu:getInfosPlayer", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source) 
	if _bConfig.id_system_l_o_s == "steam" then
		identifier = xPlayer.getIdentifier()
	elseif _bConfig.id_system_l_o_s == "license" then
		identifier = ESX.GetIdentifierFromId(source)
	end

	if _bConfig.Job2Type == 'job2' then 
		MySQL.Async.fetchAll('SELECT money, job, job2, bank FROM users WHERE identifier = @identifier', {
			['@identifier'] = identifier
		}, function (result)
			if (result[1] ~= nil) then
				player = result[1]
	
				local dataID = {
					money = player.money,
					bank = player.bank,
					job1 = player.job,
					job2 = player.job2,
				}
				cb(dataID)
			end
		end)
	elseif _bConfig.Job2Type == 'faction' then
		MySQL.Async.fetchAll('SELECT money, job, faction, bank FROM users WHERE identifier = @identifier', {
			['@identifier'] = identifier
		}, function (result)
			if (result[1] ~= nil) then
				player = result[1]
	
				local dataID = {
					money = player.money,
					bank = player.bank,
					job1 = player.job,
					job2 = player.faction,
				}
				cb(dataID)
			end
		end)
	end
end)

RegisterServerEvent('bPauseMenu:DropPlayer')
AddEventHandler('bPauseMenu:DropPlayer', function()
	DropPlayer(source, 'Vous venez de vous déconnecter du serveur '.._bConfig.ServerName)
end)