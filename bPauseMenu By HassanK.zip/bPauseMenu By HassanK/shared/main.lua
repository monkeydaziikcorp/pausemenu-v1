_bConfig = {
    ServerName = "Memory's RP",
    InitESX = "esx:getSharedObject",
    id_system_l_o_s = "steam",
    Job2Type = 'job2',

    ActivateCustomMenu = false,
    SettingTextCategory = "Paramètre de ~r~Memory's~s~ RolePlay",
    SettingTextFiveM = "Touches ~r~Memory's",
} 